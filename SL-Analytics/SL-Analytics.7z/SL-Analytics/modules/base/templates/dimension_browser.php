<div class="owa_dimensionDetail" id="">

	<div class="icon" style="float:left;">
		<img src="<?php echo $this->getBrowserIcon($properties['browser_family']);?>">
	</div>
	<div>
		<div class="title">
		<?php $this->out($properties['browser_family'], true, true); ?>
		</div>
		
	</div>
	<div style="clear:both;"></div>
	
</div>